# google_maps_flutter_example

Demonstrates how to use the google_maps_flutter plugin.

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.dev/).
