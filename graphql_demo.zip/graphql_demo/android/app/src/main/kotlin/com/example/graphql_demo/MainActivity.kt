package com.example.graphql_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
